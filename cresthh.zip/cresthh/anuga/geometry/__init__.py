"""
    Geometry classes.
    
    Classes that represent 2D geometry: polygons, quadtrees, and bounding boxes.
"""


from numpy.testing import Tester
test = Tester().test


