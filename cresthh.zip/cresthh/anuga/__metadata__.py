# Meta data for anuga
__version__ = '1.3'
__date__ = 'October 2011'
__author__ =  'Ole Nielsen, Stephen Roberts, Duncan Gray'


