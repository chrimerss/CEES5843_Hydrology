
from redfearn import *
from point import *

from numpy.testing import Tester
test = Tester().test